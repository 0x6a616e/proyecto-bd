DELIMITER //

DROP PROCEDURE IF EXISTS get_services //
CREATE PROCEDURE get_services(IN categoria_buscada VARCHAR(64))
BEGIN
SELECT nombreServicio, descripcion
FROM servicios
WHERE categoria = categoria_buscada;
END //

DROP PROCEDURE IF EXISTS validate_mail //
CREATE PROCEDURE validate_mail(IN correo_validar VARCHAR(64))
BEGIN
SELECT pid
FROM pacientes
WHERE correo = correo_validar;
END //
